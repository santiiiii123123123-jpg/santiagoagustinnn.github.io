# ¿Querés ser mi novia, Josi? 💫

Un pequeño sitio web romántico con fondo de estrellas fugaces ✨.

## Cómo usarlo
1. Abrí `index.html` con tu navegador para ver la página.
2. Podés subirlo a Netlify, GitHub Pages o Vercel para compartir el link.
